
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.11.2'
version = '1.11.2'
full_version = '1.11.2'
git_revision = ''
release = True

if not release:
    version = full_version
